/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CircleService;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author aomms
 */
@WebService(serviceName = "CircleArea")
public class CircleArea {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "area")
    public double circleArea(@WebParam(name = "radius") double radius) {
        //TODO write your implementation code here:
        return 3.14 * (radius*radius);
    }
    @WebMethod(operationName = "circum")
    public double circumFerence(@WebParam(name = "radius") double radius) {
        //TODO write your implementation code here:
        return 2 * (3.14 * radius);
    }
}
