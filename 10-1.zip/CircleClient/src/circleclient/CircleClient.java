/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circleclient;

import java.util.Scanner;

/**
 *
 * @author aomms
 */
public class CircleClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.print("radius : ");
        System.out.println("Circle Area : "+area(sc.nextDouble()));
        System.out.println("Circumference : "+circum(sc.nextDouble()));
    }
    
    private static double area(double radius) {
        serviceclient.CircleArea_Servic service = new serviceclient.CircleService_Service();
        serviceclient.CircleArea port = service.getCircleServicePort();
        return port.area(radius);
    }

    private static double circum(double radius) {
        serviceclient.CircleArea_Service service = new serviceclient.CircleService_Service();
        serviceclient.CircleArea port = service.getCircleAreaPort();
        return port.circum(radius);
    }
}
