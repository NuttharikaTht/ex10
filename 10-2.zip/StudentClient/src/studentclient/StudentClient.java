/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentclient;

/**
 *
 * @author aomms
 */
public class StudentClient {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        insertStudent("1","Max",3.78);
        findStudentById("1");
        updateStudentByid("1","Maximus",4.0);
        removeStudentById("1");
    }

    private static Student findStudentById(String id) {
        serviceclient.StudentWebService_Service service = new serviceclient.StudentWebService_Service();
        serviceclient.StudentWebService port = service.getStudentWebServicePort();
        return port.findStudentById(id);
    }

    private static Student insertStudent(String id, String name, double gpa) {
        serviceclient.StudentWebService_Service service = new serviceclient.StudentWebService_Service();
        serviceclient.StudentWebService port = service.getStudentWebServicePort();
        return port.insertStudent(id, name, gpa);
    }

    private static Student updateStudentByid(String id, String name, double gpa) {
        serviceclient.StudentWebService_Service service = new serviceclient.StudentWebService_Service();
        serviceclient.StudentWebService port = service.getStudentWebServicePort();
        return port.updateStudentByid(id, name, gpa);
    }

    private static Student removeStudentById(String id) {
        serviceclient.StudentWebService_Service service = new serviceclient.StudentWebService_Service();
        serviceclient.StudentWebService port = service.getStudentWebServicePort();
        return port.removeStudentById(id);
    }

}